<?php include_once 'top_header.php'; ?>

    <!-- Favicons-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
    
    <!-- GOOGLE WEB FONT -->
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,300,300italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Gochi+Hand' rel='stylesheet' type='text/css'>

    <!-- BASE CSS -->
    <link href="css/base.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<!--[if lte IE 8]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a>.</p>
<![endif]-->

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <header>
	<?php include_once 'menu.php'; ?>
    </header>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/sub_header_home.jpg" data-natural-width="1400" data-natural-height="350">
    <div id="subheader">
    	<div id="sub_content">
    	 <h1>Offer Terms</h1>
         
         <p></p>
        </div><!-- End sub_content -->
	</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->

    <div id="position">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li>Offer Terms</li>
               
            </ul>
            <a href="#0" class="search-overlay-menu-btn"><i class="icon-search-6"></i> Search</a>
        </div>
    </div><!-- Position -->

<!-- Content ================================================== -->
<div class="container margin_60_35">
	<div class="row">
		<div class="col-md-12">
		<center> <h2 class="nomargin_top" style="margin-bottom:30px">Offer Terms</h2></center>
		
			<h3 class="nomargin_top">TERMS AND CONDITIONS: REFERRAL PROGRAM</h3>
				<p>Offer is valid for users on the App only 
</p>			
				<p>Initial referral amount received for first order cannot be used in conjunction with any other coupon discount </p>
				<p>Referral coupons are valid only on online payments through card or netbanking. Coupons are not valid on third party wallets 
</p>
				<p>Offer cannot be clubbed with any other scheme 
</p>
				<p>Bundl Technologies Pvt. Ltd. (Swiggy) reserves the right to cancel/change/modify/add/delete any of the terms and conditions of the offer at any time without notice 
</p>
				<p>Bundl Technologies Pvt. Ltd. (Swiggy) reserves the right to terminate the offer at any time without notice 
</p>
				<p>Bundl Technologies Pvt. Ltd. (Swiggy) reserves the right to deny honouring the offer on the grounds of suspicion or abuse of the offer by any customer without providing customer any explanation thereof </p>
				<p>In no event shall Bundl Technologies Pvt. Ltd. (Swiggy) be liable for any abuse or misuse of the code due to the negligence of the customer </p>
				<p>The services shall be governed by the terms and conditions set out in http://www.swiggy.com/terms-and-conditions</p>
				<p>In case of any query regarding the offer, please email us at social@swiggy.in</p>
					<h3 class="nomargin_top">TERMS AND CONDITIONS: NON CASHBACK COUPONS
</h3>
					<p>Coupon valid on online payments only unless specified otherwise.

</p>
				<p>Offer valid for a single restaurant only.

</p>
				<p>Offer cannot be clubbed with any other scheme

</p>
				<p>Not valid on Cash on Delivery and third party wallet payments.

</p>
				<p>Cashback will be received in form of Swiggy money once order delivery is complete. The cashback will automatically applied on your next order. 
</p>
				<p>Offer valid for a single restaurant only. 
</p>
				<p>Offer cannot be clubbed with any other scheme

</p>
				<p>No refunds/redemptions of coupons/offers offered through the website or the app for cash. 
</p>
<h3 class="nomargin_top">TERMS AND CONDITIONS: REFERRAL PROGRAM</h3>
				<p>Offer is valid for users on the App only 
</p>			
				<p>Initial referral amount received for first order cannot be used in conjunction with any other coupon discount </p>
				<p>Referral coupons are valid only on online payments through card or netbanking. Coupons are not valid on third party wallets 
</p>
				<p>Offer cannot be clubbed with any other scheme 
</p>
				<p>Bundl Technologies Pvt. Ltd. (Swiggy) reserves the right to cancel/change/modify/add/delete any of the terms and conditions of the offer at any time without notice 
</p>
				<p>Bundl Technologies Pvt. Ltd. (Swiggy) reserves the right to terminate the offer at any time without notice 
</p>
				<p>Bundl Technologies Pvt. Ltd. (Swiggy) reserves the right to deny honouring the offer on the grounds of suspicion or abuse of the offer by any customer without providing customer any explanation thereof </p>
				<p>In no event shall Bundl Technologies Pvt. Ltd. (Swiggy) be liable for any abuse or misuse of the code due to the negligence of the customer </p>
				<p>The services shall be governed by the terms and conditions set out in http://www.swiggy.com/terms-and-conditions</p>
				<p>In case of any query regarding the offer, please email us at social@swiggy.in</p>
		</div>
	<!--	<div class="col-md-7 col-md-offset-1 text-right hidden-sm hidden-xs">
			<img src="img/devices.jpg" alt="" class="img-responsive">
		</div>-->
	</div><!-- End row -->
	<hr class="more_margin">
   
	
	
	
</div><!-- End container -->

<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<footer>
	<?php include_once 'footer.php'; ?>
    </footer>
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->   
<div class="modal fade" id="login_2" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myLogin">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Username">
					<input type="text" class="form-control form-white" placeholder="Password">
					<div class="text-left">
						<a href="#">Forgot Password?</a>
					</div>
					<button type="submit" class="btn btn-submit">Submit</button>
				</form>
			</div>
		</div>
	</div><!-- End modal -->   
    
<!-- Register modal -->   
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myRegister" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myRegister">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Name">
					<input type="text" class="form-control form-white" placeholder="Last Name">
                    <input type="email" class="form-control form-white" placeholder="Email">
                    <input type="text" class="form-control form-white" placeholder="Password"  id="password1">
                    <input type="text" class="form-control form-white" placeholder="Confirm password"  id="password2">
                    <div id="pass-info" class="clearfix"></div>
					<div class="checkbox-holder text-left">
						<div class="checkbox">
							<input type="checkbox" value="accept_2" id="check_2" name="check_2" />
							<label for="check_2"><span>I Agree to the <strong>Terms &amp; Conditions</strong></span></label>
						</div>
					</div>
					<button type="submit" class="btn btn-submit">Register</button>
				</form>
			</div>
		</div>
	</div><!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>