 <?php include_once 'top_header.php'; ?>
    <!-- Favicons-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
    
    <!-- GOOGLE WEB FONT -->
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,300,300italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Gochi+Hand' rel='stylesheet' type='text/css'>

    <!-- BASE CSS -->
    <link href="css/base.css" rel="stylesheet">
    
    <!-- SPECIFIC CSS -->
    <link href="css/blog.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<!--[if lte IE 8]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a>.</p>
<![endif]-->

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <header>
     <?php include_once 'menu.php'; ?>
    </header>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/sub_header_home.jpg" data-natural-width="1400" data-natural-height="350">
    <div id="subheader">
    	<div id="sub_content">
    	 <h1>QuickFood Blog</h1>
        <!-- <p>Qui debitis meliore ex, tollit debitis conclusionemque te eos.</p>-->
         <p></p>
        </div><!-- End sub_content -->
	</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->

    <div id="position">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li>Blog</li>
               
            </ul>
        </div>
    </div><!-- Position -->

<!-- Content ================================================== -->
<div class="container margin_60_35">
	<div class="row">
         
     <div class="col-md-9">
     		<div class="post">
					<a href="blog_post.php" ><img src="img/blog-1.jpg" alt="" class="img-responsive"></a>
					<div class="post_info clearfix">
						<div class="post-left">
							<ul>
							<li><i class="icon-calendar-empty"></i>15/11/2017 <em>by Admin</em></li>
                                <li><i class="icon-inbox-alt"></i><a href="#">Category</a></li>
							<!--	<li><i class="icon-tags"></i><a href="#">Works</a>, <a href="#">Personal</a></li>-->
							</ul>
						</div>
						<div class="post-right"><i class="icon-comment"></i><a href="#">2</a></div>
					</div>
					<h2>All You Need Right Now Are Delicious Pastries From These 10 Brilliant Bakeries In Delhi NCR</h2>
					<p>
						Ahhh, pastries, the best part of a meal (rather, the most important part of a meal!). Just a whiff of baked goodies are enough to make us drool! If you’ve got a sweet tooth like us, then make those sweet dreams a reality with these 10 bakeries in Delhi NCR that bake it best. ;)
					</p>
                    <p>
						Ahhh, pastries, the best part of a meal (rather, the most important part of a meal!). Just a whiff of baked goodies are enough to make us drool! If you’ve got a sweet tooth like us, then make those sweet dreams a reality with these 10 bakeries in Delhi NCR that bake it best. ;)
					</p>
					<a href="blog_post.php" class="btn_1" >Read more</a>
				</div><!-- end post -->
                                
				<div class="post">
					<a href="blog_post.php" ><img src="img/blog-2.jpg" alt="" class="img-responsive"></a>
					<div class="post_info clearfix">
						<div class="post-left">
							<ul>
								<li><i class="icon-calendar-empty"></i>15/11/2017 <em>by Admin</em></li>
                                <li><i class="icon-inbox-alt"></i><a href="#">Category</a></li>
							<!--	<li><i class="icon-tags"></i><a href="#">Works</a>, <a href="#">Personal</a></li>-->
							</ul>
						</div>
						<div class="post-right"><i class="icon-comment"></i><a href="#">2</a></div>
					</div>
					<h2>All You Need Right Now Are Delicious Pastries From These 10 Brilliant Bakeries In Delhi NCR</h2>
					<p>
						Ahhh, pastries, the best part of a meal (rather, the most important part of a meal!). Just a whiff of baked goodies are enough to make us drool! If you’ve got a sweet tooth like us, then make those sweet dreams a reality with these 10 bakeries in Delhi NCR that bake it best. ;)
					</p>
                    <p>
						Ahhh, pastries, the best part of a meal (rather, the most important part of a meal!). Just a whiff of baked goodies are enough to make us drool! If you’ve got a sweet tooth like us, then make those sweet dreams a reality with these 10 bakeries in Delhi NCR that bake it best. ;)
					</p>
					<a href="blog_post.php" class="btn_1" >Read more</a>
				</div><!-- end post -->
                
				<div class="post">
					<a href="blog_post.php" ><img src="img/blog-3.jpg" alt="" class="img-responsive"></a>
					<div class="post_info clearfix">
						<div class="post-left">
							<ul>
							<li><i class="icon-calendar-empty"></i>15/11/2017 <em>by Admin</em></li>
                                <li><i class="icon-inbox-alt"></i><a href="#">Category</a></li>
							<!--	<li><i class="icon-tags"></i><a href="#">Works</a>, <a href="#">Personal</a></li>-->
							</ul>
						</div>
						<div class="post-right"><i class="icon-comment"></i><a href="#">2</a></div>
					</div>
					<h2>All You Need Right Now Are Delicious Pastries From These 10 Brilliant Bakeries In Delhi NCR</h2>
					<p>
						Ahhh, pastries, the best part of a meal (rather, the most important part of a meal!). Just a whiff of baked goodies are enough to make us drool! If you’ve got a sweet tooth like us, then make those sweet dreams a reality with these 10 bakeries in Delhi NCR that bake it best. ;)
					</p>
                    <p>
						Ahhh, pastries, the best part of a meal (rather, the most important part of a meal!). Just a whiff of baked goodies are enough to make us drool! If you’ve got a sweet tooth like us, then make those sweet dreams a reality with these 10 bakeries in Delhi NCR that bake it best. ;)
					</p>
					<a href="blog_post.php" class="btn_1" >Read more</a>
				</div><!-- end post -->
       
              <div class="text-center">
                 <ul class="pager">
                    <li class="previous"><a href="#"><span aria-hidden="true">&larr;</span> Older</a></li>
                    <li class="next"><a href="#">Newer <span aria-hidden="true">&rarr;</span></a></li>
                  </ul>
              </div>
     </div><!-- End col-md-9-->   
     
      <aside class="col-md-3" id="sidebar">

				<div class="widget">
				<div id="custom-search-input-blog">
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="Search">
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button">
                            <i class="icon-search-1"></i>
                        </button>
                    </span>
                </div>
            </div>
				</div><!-- End Search -->
                <hr>
				<div class="widget">
					<h4>Categories</h4>
					<ul id="cat_nav_blog">
                    	<li><a href="#">News</a></li>
                        <li><a href="#">Events</a></li>
                        <li><a href="#">Special dishes</a></li>
                        <li><a href="#">New Restaurants</a></li>
                    </ul>
				</div><!-- End widget -->
 
               <hr>
            
				<div class="widget">
					<h4>Recent post</h4>
					<ul class="recent_post">
						<li>
						<i class="icon-calendar-empty"></i> 15th Nov, 2017
						<div><a href="#">It is a long established fact that a reader will be distracted </a></div>
						</li>
						<li>
						<i class="icon-calendar-empty"></i> 15th Nov, 2017
						<div><a href="#">It is a long established fact that a reader will be distracted </a></div>
						</li>
						<li>
						<i class="icon-calendar-empty"></i> 15th Nov, 2017
						<div><a href="#">It is a long established fact that a reader will be distracted </a></div>
						</li>
					</ul>
				</div><!-- End widget -->
                <hr>
				
                
     </aside><!-- End aside -->
	
  </div>
</div><!-- End container -->


<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<footer>
        <?php include_once 'footer.php'; ?>
    </footer>
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->   
<div class="modal fade" id="login_2" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myLogin">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Username">
					<input type="text" class="form-control form-white" placeholder="Password">
					<div class="text-left">
						<a href="#">Forgot Password?</a>
					</div>
					<button type="submit" class="btn btn-submit">Submit</button>
				</form>
			</div>
		</div>
	</div><!-- End modal -->   
    
<!-- Register modal -->   
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myRegister" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myRegister">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Name">
					<input type="text" class="form-control form-white" placeholder="Last Name">
                    <input type="email" class="form-control form-white" placeholder="Email">
                    <input type="text" class="form-control form-white" placeholder="Password"  id="password1">
                    <input type="text" class="form-control form-white" placeholder="Confirm password"  id="password2">
                    <div id="pass-info" class="clearfix"></div>
					<div class="checkbox-holder text-left">
						<div class="checkbox">
							<input type="checkbox" value="accept_2" id="check_2" name="check_2" />
							<label for="check_2"><span>I Agree to the <strong>Terms &amp; Conditions</strong></span></label>
						</div>
					</div>
					<button type="submit" class="btn btn-submit">Register</button>
				</form>
			</div>
		</div>
	</div><!-- End Register modal -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>