
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-3">
                <h3>Secure payments with</h3>
                <p>
                    <img src="img/cards.png" alt="" class="img-responsive">
                </p>
            </div>
            <div class="col-md-5 col-sm-5">
            <h3>Menu</h3>
				<div class="row">
				<div class="col-md-5 col-sm-5">
                <ul>
                    <li><a href="about.php">About us</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="careers.php">Careers</a></li>
					 <li><a href="#">Help&Support</a></li>                   
                 
                </ul>
			</div>
			<div class="col-md-6 col-sm-6">
                <ul>
				 <li><a href="privacy_policy.php">Privacy Policy</a></li>
                    <li><a href="offer-terms.php">Offer Terms</a></li>
				   <li><a href="terms&conditions.php">Terms and conditions</a></li>
                    <li><a href="refund_policy.php">Refunds & Cancellation Policy </a></li>
                   
                </ul>
			</div>
			<div class="col-md-1 col-sm-1">
			</div>
			</div>
            </div>
            <div class="col-md-3 col-sm-3" id="newsletter">
                <h3>Newsletter</h3>
                <p>
                    Join our newsletter to keep be informed about offers and news.
                </p>
                <div id="message-newsletter_2">
                </div>
                <form method="post" action="" name="newsletter_2" id="newsletter_2">
                    <div class="form-group">
                        <input name="email_newsletter_2" id="email_newsletter_2" type="email" value="" placeholder="Your mail" class="form-control">
                    </div>
                    <input type="submit" value="Subscribe" class="btn_1" id="submit-newsletter_2">
                </form>
            </div>
         <!--   <div class="col-md-2 col-sm-3">
                <h3>Settings</h3>
                <div class="styled-select">
                    <select class="form-control" name="lang" id="lang">
                        <option value="English" selected>English</option>
                        <option value="French">French</option>
                        <option value="Spanish">Spanish</option>
                        <option value="Russian">Russian</option>
                    </select>
                </div>
                <div class="styled-select">
                    <select class="form-control" name="currency" id="currency">
                        <option value="USD" selected>USD</option>
                        <option value="EUR">EUR</option>
                        <option value="GBP">GBP</option>
                        <option value="RUB">RUB</option>
                    </select>
                </div>
            </div>-->
        </div><!-- End row -->
        <div class="row">
            <div class="col-md-12">
                <div id="social_footer">
                    <ul>
                        <li><a href="#0"><i class="icon-facebook"></i></a></li>
                        <li><a href="#0"><i class="icon-twitter"></i></a></li>
                        <li><a href="#0"><i class="icon-google"></i></a></li>
                        <li><a href="#0"><i class="icon-instagram"></i></a></li>
                        <li><a href="#0"><i class="icon-pinterest"></i></a></li>
                        <li><a href="#0"><i class="icon-vimeo"></i></a></li>
                        <li><a href="#0"><i class="icon-youtube-play"></i></a></li>
                    </ul>
                    <p>
                        ©Food 2015. Designed By Lancius solutions.
                    </p>
                </div>
            </div>
        </div><!-- End row -->
    </div><!-- End container -->