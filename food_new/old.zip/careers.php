 <?php include_once 'top_header.php'; ?>

    <!-- Favicons-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
    
    <!-- GOOGLE WEB FONT -->
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,300,300italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Gochi+Hand' rel='stylesheet' type='text/css'>

    <!-- BASE CSS -->
    <link href="css/base.css" rel="stylesheet">
    
    <!-- Radio and check inputs -->
    <link href="css/skins/square/grey.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<!--[if lte IE 8]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a>.</p>
<![endif]-->

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <header>
     <?php include_once 'menu.php'; ?>
    </header>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/sub_header_home.jpg" data-natural-width="1400" data-natural-height="350">
    <div id="subheader">
    	<div id="sub_content">
    	 <h1>Work with us</h1>
         <p>Myservant is looking for talented individuals to join our growing team across the country.</p>
         <p></p>
        </div><!-- End sub_content -->
	</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->

    <div id="position">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li>Careers</li>
            </ul>
            <a href="#0" class="search-overlay-menu-btn"><i class="icon-search-6"></i> Search</a>
        </div>
    </div><!-- Position -->

<!-- Content ================================================== -->
<div class="container margin_60_35">
    <div class="main_title margin_mobile">
            <h2 class="nomargin_top">Flexible Job and Great fees</h2>
        </div>
	<div class="row">
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
			<div class="feature_2">
				<i class="icon_currency"></i>
				<h3>Great Fees</h3>
				<p>
					 At Swiggy, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high.
				</p>
			</div>
		</div>
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.2s">
			<div class="feature_2">
				<i class="icon_easel"></i>
				<h3>Growing possibility</h3>
				<p>
					 At Swiggy, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high.
				</p>
			</div>
		</div>
	</div><!-- End row -->
	<div class="row">
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.3s">
			<div class="feature_2">
				<i class="icon_mobile"></i>
				<h3>Manage your own orders via App</h3>
				<p>
					At Swiggy, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high.
				</p>
			</div>
		</div>
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.4s">
			<div class="feature_2">
				<i class="icon_map_alt"></i>
				<h3>Work in a small area</h3>
				<p>
					At Swiggy, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high.
				</p>
			</div>
		</div>
	</div><!-- End row -->
	<div class="row">
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.5s">
			<div class="feature_2">
				<i class="icon_clock_alt"></i>
				<h3>Flexible time</h3>
				<p>
					At Swiggy, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high.
				</p>
			</div>
		</div>
		<div class="col-md-6 wow fadeIn" data-wow-delay="0.6s">
			<div class="feature_2">
				<i class="icon_calendar"></i>
				<h3>Flexible days</h3>
				<p>
					At Swiggy, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high.
				</p>
			</div>
		</div>
	</div><!-- End row -->
</div><!-- End container -->

<div class="container-fluid">
	<div class="row">
		<div class="col-md-6 nopadding features-intro-img">
			<div class="features-bg img_2">
				<div class="features-img">
				</div>
			</div>
		</div>
		<div class="col-md-6 nopadding">
			<div class="features-content">
				<h3>"Join the Myservant Team!"</h3>
				<ul class="list_ok">
                	<li>At Myservant, we're building an on-demand food delivery startup that is delighting many customers across India with time-guaranteed deliveries and an obsession with keeping customer service levels ridiculously high..</li>
                    <li>At Myservant, we are looking for people who are concerned about the customer at all times. Customer centricity is a key tenet of all our processes.
</li>
                    <li>If this sounds exciting to you, then come have a chat with us ASAP.</li>
                </ul>
			</div>
		</div>
	</div>
</div><!-- End container-fluid  -->

<div class="container margin_60">
	 <div class="main_title margin_mobile">
            <h2 class="nomargin_top">Please submit the form below</h2>
        </div>
	<div class="row">
    	<div class="col-md-8 col-md-offset-2">
        	<form >
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>First name</label>
									<input type="text" class="form-control" id="name_contact" name="name_contact" placeholder="Name">
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>Last name</label>
									<input type="text" class="form-control" id="lastname_contact" name="lastname_contact" placeholder="SurName">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>Email:</label>
									<input type="email" id="email_contact" name="email_contact" class="form-control" placeholder="name@email.com">
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label>Phone number:</label>
									<input type="text" id="phone_contact" name="phone_contact" class="form-control" placeholder="00 44 5435435">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
                                	<h5>Do you have a motorbike or scooter?</h5>
									<label><input name="motor" type="radio" value="" class="icheck" checked>Yes</label>
                                    <label class="margin_left"><input name="motor" type="radio" value="" class="icheck">No</label>
								</div>
							</div>
                            <div class="col-md-6">
								<div class="form-group">
                                	<h5>Are you a student?</h5>
									<label><input name="student" type="radio" value="" class="icheck" checked>Yes</label>
                                    <label class="margin_left"><input name="student" type="radio" value="" class="icheck">No</label>
								</div>
							</div>
						</div><!-- End row  -->
                        <div class="row">
							<div class="col-md-6">
								<div class="form-group">
                                	<h5>Do you have a driving license?</h5>
									<label><input name="license" type="radio" value="" class="icheck" checked>Yes</label>
                                    <label class="margin_left"><input name="license" type="radio" value="" class="icheck">No</label>
								</div>
							</div>
                            <div class="col-md-6">
								<div class="form-group">
                                	<h5>Do you have an iPhone or Android mobile?</h5>
									<label><input name="mobile" type="radio" value="" class="icheck" checked>Yes</label>
                                    <label class="margin_left"><input name="mobile" type="radio" value="" class="icheck">No</label>
								</div>
							</div>
						</div><!-- End row  -->
                        <hr style="border-color:#ddd;">
                        <div class="text-center"><button class="btn_full_outline">Submit</button></div>
					</form>
        </div><!-- End col  -->
    </div><!-- End row  -->
</div><!-- End container  -->
<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<footer>
         <?php include_once 'footer.php'; ?>
    </footer>
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->   
<div class="modal fade" id="login_2" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myLogin">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Username">
					<input type="text" class="form-control form-white" placeholder="Password">
					<div class="text-left">
						<a href="#">Forgot Password?</a>
					</div>
					<button type="submit" class="btn btn-submit">Submit</button>
				</form>
			</div>
		</div>
	</div><!-- End modal -->   
    
<!-- Register modal -->   
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myRegister" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myRegister">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Name">
					<input type="text" class="form-control form-white" placeholder="Last Name">
                    <input type="email" class="form-control form-white" placeholder="Email">
                    <input type="text" class="form-control form-white" placeholder="Password"  id="password1">
                    <input type="text" class="form-control form-white" placeholder="Confirm password"  id="password2">
                    <div id="pass-info" class="clearfix"></div>
					<div class="checkbox-holder text-left">
						<div class="checkbox">
							<input type="checkbox" value="accept_2" id="check_2" name="check_2" />
							<label for="check_2"><span>I Agree to the <strong>Terms &amp; Conditions</strong></span></label>
						</div>
					</div>
					<button type="submit" class="btn btn-submit">Register</button>
				</form>
			</div>
		</div>
	</div><!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>