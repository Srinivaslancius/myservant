 <?php include_once 'top_header.php'; ?>

    <!-- Favicons-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
    
    <!-- GOOGLE WEB FONT -->
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,300,300italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Gochi+Hand' rel='stylesheet' type='text/css'>

    <!-- BASE CSS -->
    <link href="css/base.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<!--[if lte IE 8]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a>.</p>
<![endif]-->

	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload -->

    <!-- Header ================================================== -->
    <header>
	 <?php include_once 'menu.php'; ?>
    </header>
    <!-- End Header =============================================== -->

<!-- SubHeader =============================================== -->
<section class="parallax-window" id="short" data-parallax="scroll" data-image-src="img/sub_header_home.jpg" data-natural-width="1400" data-natural-height="350">
    <div id="subheader">
    	<div id="sub_content">
    	 <h1>Terms & Conditions</h1>
         
         <p></p>
        </div><!-- End sub_content -->
	</div><!-- End subheader -->
</section><!-- End section -->
<!-- End SubHeader ============================================ -->

    <div id="position">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li>Terms & Conditions</li>
               
            </ul>
            <a href="#0" class="search-overlay-menu-btn"><i class="icon-search-6"></i> Search</a>
        </div>
    </div><!-- Position -->

<!-- Content ================================================== -->
<div class="container margin_60_35">
	<div class="row">
		<div class="col-md-12">
		<center> <h2 class="nomargin_top">Terms & Conditions </h2></center>
		<p>This document is an electronic record in terms of Information Technology Act, 2000 and rules there under as applicable and the amended provisions pertaining to electronic records in various statutes as amended by the Information Technology Act, 2000. This document is published in accordance with the provisions of Rule 3 (1) of the Information Technology (Intermediaries guidelines) Rules, 2011 that require publishing the rules and regulations, privacy policy and Terms of Use for access or usage of www.swiggy.com website and Swiggy application for mobile and handheld devices.</p>
			<h3 class="nomargin_top">Terms Of Use</h3>			
				<ol type="I">
				<li>These terms of use (the “Terms of Use”) govern your use of our website www.swiggy.com (the “Website”) and our “Swiggy” application for 
				mobile and handheld devices (the “App”). The Website and the App are jointly referred to as the “Platform”. Please read these Terms of Use 
				carefully before you use the services. If you do not agree to these Terms of Use, you may not use the services on the Platform, and we request 
				you to uninstall the App. By installing, downloading or even merely using the Platform, you shall be contracting with Swiggy and you signify
				your acceptance to the Terms of Use and other Swiggy policies (including but not limited to the Cancellation & Refund Policy, Privacy Policy
				and Take Down Policy) as posted on the Platform from time to time, which takes effect on the date on which you download, install or use the 
				Services, and create a legally binding arrangement to abide by the same.</li><br>
				<li>The Platform is operated and owned by Bundl Technologies Private Limited, a company incorporated under the Companies Act, 1956 and having its registered office at No. 17/9B, 4th Floor, Maruthi Chambers, Rupena Agrahara, Hosur Road, Bangalore – 560 068. For the purpose of these Terms of Use, wherever the context so requires, ”you” shall mean any natural or legal person who has agreed to become a buyer or customer on the Platform by providing Registration Data while registering on the Platform as a registered user using any computer systems. The terms “Swiggy”, “we”, “us” or “our” shall mean Bundl Technologies Private Limited.</li><br>
				<li>Swiggy enables transactions between participant restaurants/merchants and buyers, dealing in prepared food and beverages (“Platform Services”). The buyers (“Buyer/s”) can choose and place orders (“Orders”) from variety of products listed and offered for sale by various neighbourhood merchants including but not limited to the restaurants and eateries (“Merchant/s”), on the Platform and Swiggy enables delivery of such orders at select localities of serviceable cities across India (“Delivery Services”). The Platform Services and Delivery Services are collectively referred to as “Services”.</li><br>
				
		<li><h3 class="nomargin_top">AMENDMENTS</h3>		
				
				These terms of use (the “Terms of Use”) govern your use of our website www.swiggy.com (the “Website”) and our “Swiggy” application for 
				mobile and handheld devices (the “App”). The Website and the App are jointly referred to as the “Platform”. Please read these Terms of Use 
				carefully before you use the services. If you do not agree to these Terms of Use, you may not use the services on the Platform, and we request 
				you to uninstall the App. By installing, downloading or even merely using the Platform, you shall be contracting with Swiggy and you signify
				your acceptance to the Terms of Use and other Swiggy policies (including but not limited to the Cancellation & Refund Policy, Privacy Policy
				and Take Down Policy) as posted on the Platform from time to time, which takes effect on the date on which you download, install or use the 
				Services, and create a legally binding arrangement to abide by the same.</li><br>
<li><h3 class="nomargin_top">Use of Platform and Services</h3>
<ol type="1">	
<li>All commercial/contractual terms are offered by and agreed to between Buyers and Merchants alone. The commercial/contractual terms include without limitation price, taxes, shipping costs, payment methods, payment terms, date, period and mode of delivery, warranties related to products and services and after sales services related to products and services. Swiggy does not have any control or does not determine or advise or in any way involve itself in the offering or acceptance of such commercial/contractual terms between the Buyers and Merchants. Swiggy may, however, offer support services to Merchants in respect to order fulfilment, payment collection, call centre, and other services, pursuant to independent contracts executed by it with the Merchants.</li>
<li>Swiggy does not make any representation or warranty as to the item-specifics (such as legal title, creditworthiness, identity, etc.) of any of the Merchants. You are advised to independently verify the bona fides of any particular Merchant that you choose to deal with on the Platform and use your best judgment in that behalf. All Merchant offers and third party offers are subject to respective party terms and conditions. Swiggy takes no responsibility for such offers.</li>
<li>Swiggy neither make any representation or warranty as to specifics (such as quality, value, salability, etc.) of the products or services proposed to be sold or offered to be sold or purchased on the Platform nor does implicitly or explicitly support or endorse the sale or purchase of any products or services on the Platform. Swiggy accepts no liability for any errors or omissions, whether on behalf of itself or third parties.</li>
<li>Swiggy is not responsible for any non-performance or breach of any contract entered into between Buyers and Merchants on the Platform. Swiggy cannot and does not guarantee that the concerned Buyers and/or Merchants will perform any transaction concluded on the Platform. Swiggy is not responsible for unsatisfactory or non-performance of services or damages or delays as a result of products which are out of stock, unavailable or back ordered.</li>	
				</ol>
				</li>				
				</ol>
				<h3 class="nomargin_top">Format of notice of infringement</h3>
				<p>To,</p>
<p>Bundl Technologies Private Limited,</p>
<p>No. 17/9B, 4th Floor, Maruthi Chambers,</p>
<p>Rupena Agrahara, Hosur Road, Bangalore – 560 068</p>


<p>I, <<insert name>>____________________________ of <<insert address>> _________________________ do solemnly and sincerely declare as follows:</p>

<p>1. I am the owner of certain intellectual property rights, said owner being named __________________ (“IP Owner”).</p>

<p>2. I have a good faith belief that use of the material in the manner complained of is not authorized by the intellectual property right(s) owner, its agent, or the law therefore infringe the IP Owner's rights. Please expeditiously remove or disable access to the material claimed to be infringing.

<p>3. I may be contacted at:</p>

<p>Name____________________________________________________________________________
Designation/Title & Company_________________________________________________________
Postal Address (with Pin code)________________________________________________________
Email Address (correspondence)_______________________________________________________
Telephone/Fax_____________________________________________________________________


<p>I swear, under penalty of perjury, that the information in the notification is accurate, and that I am the intellectual property right(s) owner or am authorized to act on behalf of the owner of an exclusive intellectual property right(s) that is allegedly infringed and I make this declaration conscientiously believing it to be true and correct.</p>

Declared by <<insert name>>______________________________
on <<insert date>> ___________________________________ at <<insert place>> ________


<p>Truthfully,</p>
<p>Signature ________________________</p>

<p>(Important Note: (a) Swiggy shall be unable to process requests which do not specify exact product IDs or URLs. Please do not provide links to browse pages or links of search queries as these pages are dynamic and their contents change with time. (b) Swiggy shall not consider an incomplete request. (c) Swiggy’s response to such request will include removing or disabling access to material claimed to be the subject of infringing activity. For a detailed term of use of our Platform, please visit https://www.swiggy.com/terms-and-conditions).</p>
		</div>
	<!--	<div class="col-md-7 col-md-offset-1 text-right hidden-sm hidden-xs">
			<img src="img/devices.jpg" alt="" class="img-responsive">
		</div>-->
	</div><!-- End row -->
	<hr class="more_margin">
   
	
	
	
</div><!-- End container -->

<!-- End Content =============================================== -->

<!-- Footer ================================================== -->
	<footer>
         <?php include_once 'footer.php'; ?>
    </footer>
<!-- End Footer =============================================== -->

<div class="layer"></div><!-- Mobile menu overlay mask -->

<!-- Login modal -->   
<div class="modal fade" id="login_2" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myLogin">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Username">
					<input type="text" class="form-control form-white" placeholder="Password">
					<div class="text-left">
						<a href="#">Forgot Password?</a>
					</div>
					<button type="submit" class="btn btn-submit">Submit</button>
				</form>
			</div>
		</div>
	</div><!-- End modal -->   
    
<!-- Register modal -->   
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myRegister" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content modal-popup">
				<a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
				<form action="#" class="popup-form" id="myRegister">
                	<div class="login_icon"><i class="icon_lock_alt"></i></div>
					<input type="text" class="form-control form-white" placeholder="Name">
					<input type="text" class="form-control form-white" placeholder="Last Name">
                    <input type="email" class="form-control form-white" placeholder="Email">
                    <input type="text" class="form-control form-white" placeholder="Password"  id="password1">
                    <input type="text" class="form-control form-white" placeholder="Confirm password"  id="password2">
                    <div id="pass-info" class="clearfix"></div>
					<div class="checkbox-holder text-left">
						<div class="checkbox">
							<input type="checkbox" value="accept_2" id="check_2" name="check_2" />
							<label for="check_2"><span>I Agree to the <strong>Terms &amp; Conditions</strong></span></label>
						</div>
					</div>
					<button type="submit" class="btn btn-submit">Register</button>
				</form>
			</div>
		</div>
	</div><!-- End Register modal -->
    
     <!-- Search Menu -->
	<div class="search-overlay-menu">
		<span class="search-overlay-close"><i class="icon_close"></i></span>
		<form role="search" id="searchform" method="get">
			<input value="" name="q" type="search" placeholder="Search..." />
			<button type="submit"><i class="icon-search-6"></i>
			</button>
		</form>
	</div>
	<!-- End Search Menu -->
    
<!-- COMMON SCRIPTS -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/common_scripts_min.js"></script>
<script src="js/functions.js"></script>
<script src="assets/validate.js"></script>

</body>
</html>